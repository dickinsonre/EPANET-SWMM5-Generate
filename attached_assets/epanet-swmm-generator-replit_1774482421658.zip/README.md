# EPANET 2.3 & SWMM 5.2.4 Network Generator

**Single-file browser application for generating hydraulically valid water distribution and stormwater collection models.**

266 KB · 68 functions · 122 tooltips · 0 dependencies · Mobile-optimized

---

## Quick Start

1. Open `index.html` in any browser (or deploy on Replit)
2. Select **EPANET 2.3** or **SWMM 5.2.4** mode
3. Pick a preset (Tiny through City/100K)
4. Click **Generate**
5. Download the `.inp` file and load into EPANET, SWMM, or any compatible solver

---

## Files in This Package

| File | Size | Description |
|------|------|-------------|
| `index.html` | 266 KB | Complete generator application (single file, no dependencies) |
| `heinlein-review.html` | 16 KB | A− grade review from Robert Heinlein's perspective (starship engineer) |
| `asimov-review.html` | 22 KB | A− grade review from Asimov/Foundation perspective (civilizational preservation) |
| `intern-review.html` | 25 KB | B+ grade review from engineering intern (UX, bugs, feature requests) |
| `deep-dive-report.html` | 14 KB | C+ technical audit (18 domains graded, 16 fixes prioritized) |
| `README.md` | This file |

---

## EPANET 2.3 Mode — Water Distribution

### Network Topology
- Grid-based layout with configurable jitter, diagonal cross-connections, dead-end branches
- 8 presets: Tiny (50) → Small (150) → Medium (750) → Large (2500) → XL (5000) → Mega (10K) → Giant (50K) → City (100K)
- Seeded PRNG (Mulberry32) — change the seed to get different networks from the same parameters

### Hydraulic Elements
- **Reservoirs** — placed at perimeter, integrated into grid (no floating nodes)
- **Tanks** — base elevation computed from pressure zone requirements (TANK_HGL_FRACTION = 0.85)
- **Pumps** — source pumps sized via BFS critical-path Hazen-Williams friction analysis; boosters split existing pipes with closed bypass
- **Valves** — PRVs auto-placed at elevation zone boundaries (>80 ft range triggers pressure zones); FCVs placed randomly; all valves split pipes (no parallel links); tank/reservoir connection guard (EPANET Error 219 prevention)
- **Pipes** — length × 1.3 street-routing factor; diameters: transmission (24-36") near sources, secondary (12-20") on arterials, distribution (6-12") elsewhere
- **Pipe Age** — installation year correlated with distance from center (1950s downtown → 2020s suburban), written as decade tags (YR1960s)
- **C-factors** — spatially correlated with pipe age and position (downtown = old = low C, suburban = new = high C)

### Demand Zones
- Four zones spatially clustered (not random): Industrial (NW corner), Commercial (central spine), Mixed (defined area), Residential (fill)
- Four diurnal patterns: residential (morning/evening peaks), commercial (midday), industrial (plateau), mixed (blend)
- Optional secondary demands, emitter nodes (leaks/hydrants)

### Pressure Zones
- Auto-detected when terrain elevation range > 80 ft
- PRVs placed at pipes crossing zone break elevations
- PRV settings computed: downstream elevation + 50 psi × 2.31 ft/psi

### Validation
- **BFS connectivity check** — verifies all junctions reachable from sources
- **Supply-demand ratio** — green/red indicator in Stats tab
- **Mass balance** — total/peak demand computed, compared to pump capacity
- **Monotonic pump IDs** — prevents duplicate ID errors (PU6/PU13 fix)

### .inp Compliance (EPANET 2.2+)
All seven Rossman review defects corrected:
1. No parallel pumps/valves (pipe-splitting insertion)
2. No floating reservoirs (integrated into grid)
3. Pump curves sized to system hydraulics (BFS friction)
4. Pipe lengths include street-routing factor
5. C-factors spatially correlated
6. Demand zones spatially clustered
7. Mass balance verified

---

## SWMM 5.2.4 Mode — Stormwater & Sanitary Sewer

### Network Elements
- **Junctions** — manholes with invert = ground elevation − cover depth
- **Outfalls** — placed at lowest-elevation perimeter nodes (FREE discharge)
- **Conduits** — gravity sewers oriented downhill; minimum 0.5% slope enforced
- **10 Cross-Section Shapes** — Circular, Rectangular Closed, Arch, Egg, Horseshoe, Gothic, Catenary, Basket Handle, Semi-Elliptical, Semi-Circular — with configurable mix percentages
- **Culverts** — configurable count, FHWA entrance codes, Kentry/Kexit loss coefficients
- **Pump Stations** — wet well nodes at low points, Type 3 or Type 1 pump curves sized to elevation difference
- **Force Mains** — CIRCULAR conduits inside [CONDUITS]/[XSECTIONS], pressurized via FORCE_MAIN_EQUATION H-W in OPTIONS

### Subcatchments
- One per junction node
- Areas scaled to grid footprint (gridArea / junctionCount) — not arbitrary
- Width proportional to sqrt(area)
- Impervious % varies by land-use zone (Residential 35%, Commercial 85%, Industrial 72%)
- Thiessen (Voronoi) polygons computed from junction coordinates for realistic drainage boundaries

### Hydrology
- **Design Storms** — SCS Type I, SCS Type II (24-hr), Uniform (6-hr), Chicago (2-hr)
- **Infiltration** — Horton (max/min rate, decay), Green-Ampt (suction, Ksat, IMD), Curve Number
- **Parameters vary by subcatchment** with spatial randomization

### Water Quality
- 8 pollutants: TSS, BOD, COD, TN, TP, Zinc, Oil & Grease, E.coli
- EMC washoff with zone-specific concentrations
- 4 land uses: Residential, Commercial, Industrial, OpenSpace
- Full sections: POLLUTANTS, LANDUSES, COVERAGES, BUILDUP, WASHOFF

### Groundwater
- Aquifer definition: porosity, field capacity, Ksat, GW table depth
- Per-subcatchment GROUNDWATER entries with A1/B1 lateral flow coefficients
- Controlled via IGNORE_GROUNDWATER option

### RDII (Rainfall-Derived Inflow & Infiltration)
- 5 spatially-distributed RTK unit hydrograph groups (UH1-UH5)
- UH1 = old downtown (high R, fast T) → UH5 = new suburban (low R, slow T)
- Each group has randomized R/T/K for short, medium, and long triangle responses
- Configurable % of nodes receiving RDII, variable sewer area per node
- Comments in .inp document each UH group's purpose

### Dry Weather Flow
- 3 zone-specific diurnal patterns:
  - DWF_DIURNAL — residential (morning 8am + evening 7pm peaks)
  - DWF_COMMERCIAL — midday-heavy
  - DWF_INDUSTRIAL — sustained 7am-4pm plateau
- Optional DWF_WEEKEND pattern (85% of weekday, shifted 2 hrs later)
- Optional DWF_MONTHLY seasonal variation
- Configurable % of nodes, base flow with zone multipliers (commercial ×1.5, industrial ×2.0)

### Direct Inflows
- Configurable number of nodes with triangle-hydrograph timeseries
- Peak flow, ramp-up time, duration configurable
- Start times staggered randomly across simulation
- Optional TSS concentration timeseries with first-flush exponential decay

### LID Controls
- 7 types: Bio-Retention Cell, Permeable Pavement, Infiltration Trench, Rain Barrel, Vegetative Swale, Green Roof, Rain Garden
- Full multi-layer definitions (SURFACE, SOIL, STORAGE, PAVEMENT, DRAIN, DRAINMAT)
- Configurable % of subcatchments receiving LID (LID area = 5% of subcatchment)

### Snowmelt (Optional)
- Dividing temperature, melt coefficient, ATI weight
- Snowpack definitions (PLOWABLE, IMPERVIOUS, PERVIOUS)
- Temperature timeseries with diurnal variation

### .inp Compliance (SWMM 5.2+)
- Section ordering: JUNCTIONS/OUTFALLS/CONDUITS before DWF/RDII/INFLOWS (node-definition-first rule)
- FLOW_ROUTING (not ROUTING_MODEL)
- End date computed with JavaScript Date object (handles >31 day durations)
- Force mains as CIRCULAR inside [CONDUITS]/[XSECTIONS] (not orphan lines)
- No duplicate [TIMESERIES] headers

---

## Unit Systems

- **US Customary** — EPANET: GPM, ft, in. SWMM: CFS, ft, in, acres
- **SI / Metric** — EPANET: LPS, m, mm. SWMM: CMS, m, mm, hectares
- Conversion applied at INP output (internal calculations always in US units)
- All elevations, lengths, diameters, demands, and pump curves converted

---

## Visualization

### Map Canvas
- Procedural city map: streets, buildings, parks, lakes, river, railroad, highway
- 3 styles: Light (paper map), Satellite (dark), Blueprint
- Network overlay: nodes, reservoirs (green circles), tanks (amber squares), pumps (red triangles), valves (purple dots)
- **Pipe Diameter coloring**: cyan=small, blue=medium, amber=large, red=trunk
- **Elevation heatmap**: blue-green-red color ramp
- **Voronoi polygons**: zone-colored Thiessen cells (disabled >5000 nodes with message)
- **Results overlay** (after solver): nodes colored by pressure/depth, pipes by velocity, flow direction arrows
- **Legend overlay**: semi-transparent top-right corner, always visible
- **Time slider + animation**: scrub through timesteps, auto-play at 150ms

### HGL Profile
- BFS shortest path from lowest to highest elevation node
- Ground surface (brown), pipe crown (blue), invert (cyan), HGL (dashed cyan)
- Pump markers (red triangles)
- Uses computed head from solver when available, falls back to static estimate
- "⚠ ESTIMATED" or "✓ COMPUTED" label based on solver state
- Downloadable as PNG

### Stats Tab
- Junction, reservoir, tank, pipe, pump, valve counts
- Supply Status (green ✓ / red ⚠), S/D ratio
- Pressure zones, elevation range
- Connectivity % and isolated node count
- Zone breakdown, INP size

---

## Solver Integration (WebAssembly)

### Architecture
The app includes a complete WASM solver scaffold that can run EPANET or SWMM in-browser:

1. **Load WASM Engine** — select .js glue + .wasm binary (compiled via Emscripten)
2. **Run Solver** — writes .inp to Emscripten virtual filesystem, calls solver API, reads binary .out
3. **Parse Results** — binary .out parser extracts per-node/per-link results at each timestep
4. **Visualize** — pressure/depth/velocity coloring on map with time animation

### Three Modes
- **Full Emscripten module** — calls real C API: `EN_open`, `EN_solveH`, `EN_solveQ`, `EN_close` (EPANET) or `swmm_run` (SWMM)
- **Raw WASM binary** — stores binary for manual instantiation
- **Demo mode** — generates physically plausible synthetic results for visualization testing without any WASM files

### How to Compile the WASM Files

**EPANET:**
```bash
git clone https://github.com/OpenWaterAnalytics/EPANET.git
cd EPANET
emcmake cmake -B build -DBUILD_SHARED_LIBS=OFF
emmake make -C build
# produces: epanet.js + epanet.wasm (~400 KB)
```

**SWMM:**
```bash
git clone https://github.com/nicmcd/swmm-js.git  # or your fork
cd swmm-js
emcc src/swmm5.c src/climate.c src/controls.c src/culvert.c src/datetime.c \
  src/dwflow.c src/dynwave.c src/error.c src/exfil.c src/findroot.c \
  src/flowrout.c src/forcmain.c src/gage.c src/gwater.c src/hash.c \
  src/hotstart.c src/iface.c src/infil.c src/inflow.c src/input.c \
  src/inputr.c src/keywords.c src/kinwave.c src/landuse.c src/lid.c \
  src/lidproc.c src/link.c src/massbal.c src/mathexpr.c src/mempool.c \
  src/node.c src/odesolve.c src/output.c src/project.c src/qualrout.c \
  src/rain.c src/rdii.c src/report.c src/roadway.c src/routing.c \
  src/runoff.c src/shape.c src/snow.c src/stats.c src/statsrpt.c \
  src/subcatch.c src/surfqual.c src/table.c src/toposort.c src/transect.c \
  src/treatmnt.c src/xsect.c \
  -o swmm.js \
  -s WASM=1 \
  -s EXPORTED_FUNCTIONS="['_swmm_run','_swmm_open','_swmm_start','_swmm_step','_swmm_end','_swmm_close']" \
  -s EXPORTED_RUNTIME_METHODS="['FS','ccall','cwrap']" \
  -s ALLOW_MEMORY_GROWTH=1 \
  -O2
# produces: swmm.js + swmm.wasm (~600 KB)
```

### Demo Mode (No WASM Required)
Click "Run Solver" without loading WASM files → generates demo results:
- **EPANET**: diurnal pressure variation (40-80 psi cycling with morning/evening peaks)
- **SWMM**: storm hydrograph response (depth rises with Gaussian storm at hour 12, then recedes)
- Flow direction arrows, velocity coloring, time animation all work with demo data
- RPT and HTML reports show demo data clearly labeled

---

## Report Outputs

### RPT Tab (Text Report)
After running the solver, the RPT tab shows a classic EPANET/SWMM text report:
- Network summary (node/link counts, simulation parameters)
- Node results at peak demand (EPANET) or peak storm (SWMM)
- Pressure statistics / flooding summary
- Link results (max flow, max velocity)
- System performance summary
- Download as `.rpt` file or copy to clipboard

### Results Tab (HTML Report)
Formatted HTML report with:
- Color-coded summary stat cards (min/max pressure, surcharging nodes, max velocity)
- Node results table sorted by worst condition (low pressure or high depth)
- Link results table sorted by max velocity with inline bar charts
- Zone summary table (aggregated by Residential/Commercial/Industrial/Mixed)
- Status indicators: green=OK, amber=Caution, red=Warning
- Download as standalone `.html` file (prints cleanly)

---

## Export Formats

| Format | Button | Description |
|--------|--------|-------------|
| `.inp` | ↓ .inp | EPANET 2.2+ or SWMM 5.2+ input file |
| PNG | ↓ Map PNG / Map+Net | City map ± network overlay (2400×1600 @ 2× DPI) |
| DEM | ↓ DEM | ESRI ASCII grid (.asc) with IDW-interpolated elevations |
| GeoJSON | ↓ GeoJSON | Nodes as Points, pipes as LineStrings, with attributes |
| RPT | ↓ .rpt | Text report file (after solver run) |
| HTML | ↓ HTML Report | Formatted results report (after solver run) |
| Config | 💾 Config | JSON export of all settings (restore with 📂 Load) |
| HGL PNG | ↓ Save PNG | HGL profile as PNG image |
| Clipboard | 📋 Copy | Full .inp text to clipboard |

---

## Named Constants

All magic numbers extracted to named constants at the top of the script:

| Constant | Value | Meaning |
|----------|-------|---------|
| `STREET_LENGTH_FACTOR` | 1.3 | Euclidean → street-routed pipe length multiplier |
| `PEAKING_FACTOR` | 1.6 | Peak demand / average demand ratio |
| `PSI_TO_FT` | 2.31 | 1 psi = 2.31 ft of head |
| `TANK_HGL_FRACTION` | 0.85 | Tank base = 85% of source HGL at that location |
| `MIN_PRESSURE_PSI` | 20 | Minimum acceptable system pressure (psi) |
| `PUMP_SHUTOFF_FACTOR` | 1.33 | Shutoff head = 133% of design head |
| `BOUNDARY_PAD_PCT` | 0.08 | Map boundary padding as fraction of extent |

---

## Keyboard Shortcuts

| Shortcut | Action |
|----------|--------|
| Ctrl+G | Generate network |
| Ctrl+S | Download .inp file |

---

## Accessibility

- `role="button"` + `aria-expanded` on all collapsible sections
- `role="tab"` on tab buttons
- `aria-label` on icon-only buttons
- Keyboard Enter/Space to toggle sections
- 122 parameter tooltips (hover/long-press)
- Input validation: all numeric fields clamped to min/max on blur

---

## Performance Notes

- `safeMin()` / `safeMax()` loop functions replace `Math.min/max(...array)` spread operators — prevents stack overflow on 100K-node networks
- Voronoi rendering disabled above 5,000 nodes (with user message)
- try/catch/finally on both generators — button always resets on error
- Pumps/valves capped at 30% of pipe count to prevent orphan nodes on small grids

---

## Known Limitations

1. **Not a solver** — generates models, does not compute hydraulic results (unless WASM engine loaded)
2. **Grid-based topology** — real street networks have curves, cul-de-sacs, irregular blocks
3. **No 2D overland flow** — SWMM 5 supports 2D meshes but this generator doesn't create them
4. **No [RULES] section** — EPANET pump/tank control rules not generated
5. **No [TRANSECTS]** — irregular open channel cross-sections not generated
6. **HGL is estimated** — static approximation, not computed (unless solver results available)
7. **Not for design** — for teaching, calibration testing, algorithm development

---

## Build History

- **Phase 1**: EPANET grid generator with terrain, city map
- **Phase 2**: Mobile optimization (bottom drawer, touch targets)
- **Phase 3**: Download fallbacks for artifact iframe
- **Phase 4-8**: Seven Rossman review fixes (C− → B+)
- **Phase 9-10**: Five A-grade fixes (B+ → A−): BFS pump sizing, pressure zones, supply-demand check, pipe age, connectivity validation
- **Phase 11**: SWMM 5.2.4 mode with subcatchments, conduits, design storms, infiltration
- **Phase 12**: SWMM WQ, GW, RDII, LID, snowmelt, mixed shapes, culverts
- **Phase 13**: DWF patterns, direct inflows, 5 randomized RDII UH groups
- **Phase 14**: US/SI units, Voronoi polygons, 10 conduit shapes, Docs tab
- **Phase 15**: SWMM pumps, force mains, HGL profile
- **Phase 16**: All intern suggestions (random seed, pipe diameter viz, tooltips, legend, named constants, count preview)
- **Phase 17**: Deep dive fixes (stack overflow, flat terrain guard, end date, SI conversion, slope enforcement, subcatchment scaling, input validation, GeoJSON, config save/load, ARIA, error recovery)
- **Phase 18**: WASM solver scaffold (both engines), binary parsers, results visualization, time animation, RPT + HTML reports
- **Phase 19**: 122 tooltips on every parameter

---

## Credits

Built by Robert (Bob) Dickinson — Autodesk Water Technologist, TAC Chair for SWMM5+ at CIMM.org, 50+ years continuous SWMM development experience (versions 3, 4, 5, 5+).

EPANET engine logic informed by Rossman's EPANET 2.2 Users Manual. SWMM engine logic informed by EPA SWMM 5.2 Reference Manual. Design storm distributions from SCS TR-55. RTK unit hydrograph methodology from SWMM RDII documentation. Diurnal demand/DWF patterns from standard utility practice. C-factor ranges from AWWA Manual M36.

---

## License

Educational tool for teaching, calibration testing, and algorithm development.
Not for design or compliance submissions.
